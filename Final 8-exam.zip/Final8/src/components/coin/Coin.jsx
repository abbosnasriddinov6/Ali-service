import React from 'react'

const Coin = () => {
  return (
    <div>Coin</div>
  )
}

export default Coin